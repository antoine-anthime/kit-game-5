import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

# Import getPredictForAllDaysInNextWeek() from main2.py
from main2 import getPredictForAllDaysInNextWeek
from main2 import getPredictForNextDay

df = getPredictForAllDaysInNextWeek()
dfNextDay = getPredictForNextDay()

plt.figure(figsize=(10, 5))
df.plot(x='Date_Heure', y=['consommation', 'consommation_pred'], figsize=(15, 5))
plt.legend()

# Affiche logo.png
st.image("logo.png")
# Ecrit "Hello World" dans le titre de la page
st.title("KIT GAME - Equipe 1")

#Ecrit "Prédictions de la consommation électrique" dans le titre de la page
st.title("Prédictions de la consommation électrique")

# Fais un bouton "Charger la prédiction"
if st.button("Charger la prédiction"):
    # Affiche le dataframe
    st.dataframe(df)
    # Affiche le graphique
    st.pyplot(plt)

# Fais un bouton "Charger la prédiction pour demain"
if st.button("Charger la prédiction pour demain"):
    # Affiche le dataframe
    st.dataframe(dfNextDay)
    dfNextDay.plot(x='Date_Heure', y=['consommation', 'consommation_pred'], figsize=(15, 5))
    # Affiche le graphique
    st.pyplot(plt)